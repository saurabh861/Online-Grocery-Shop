-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 09, 2021 at 10:41 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 5.6.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ogs`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `uname` varchar(200) NOT NULL,
  `passwd` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`uname`, `passwd`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `pid` int(11) NOT NULL,
  `pname` varchar(200) NOT NULL,
  `ctype` varchar(200) NOT NULL,
  `ptype` varchar(200) NOT NULL,
  `qty` int(11) NOT NULL,
  `unit` varchar(200) NOT NULL,
  `rate` int(11) NOT NULL,
  `cname` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `fname` varchar(200) NOT NULL,
  `mname` varchar(200) NOT NULL,
  `lname` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `mobileno` varchar(200) NOT NULL,
  `adhaar` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`fname`, `mname`, `lname`, `username`, `password`, `address`, `mobileno`, `adhaar`, `email`) VALUES
('Aishwarya', 'Shrishail', 'Gaikwad', 'aishwarya@gmail.com', 'abcdefgh', 'solapur', '7020907859', '1245637896', 'ganesh0633@gmail.com'),
('ganesh', 'chandrakant', 'rampure', 'ganesh0633@gmail.com', 'abcdefgh', 'solapur', '8999050631', '1245637896', 'ganesh0633@gmail.com'),
('', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', ''),
('', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `delivery`
--

CREATE TABLE `delivery` (
  `pid` int(11) NOT NULL,
  `pname` varchar(200) NOT NULL,
  `ctype` varchar(200) NOT NULL,
  `ptype` varchar(200) NOT NULL,
  `qty` int(11) NOT NULL,
  `unit` varchar(200) NOT NULL,
  `rate` int(11) NOT NULL,
  `cname` varchar(200) NOT NULL,
  `flag` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `delivery`
--

INSERT INTO `delivery` (`pid`, `pname`, `ctype`, `ptype`, `qty`, `unit`, `rate`, `cname`, `flag`) VALUES
(4, 'rice', 'Grocery', 'ambemohor', 1, 'kg', 55, 'ganesh0633@gmail.com', 2),
(5, 'wheat', 'Grocery', 'lahu', 1, 'kg', 32, 'ganesh0633@gmail.com', 2);

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `invoiceid` int(11) NOT NULL,
  `cname` varchar(200) NOT NULL,
  `transactionid` varchar(200) NOT NULL,
  `mop` varchar(200) NOT NULL,
  `dateofp` varchar(200) NOT NULL,
  `amt` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`invoiceid`, `cname`, `transactionid`, `mop`, `dateofp`, `amt`) VALUES
(14, 'ganesh0633@gmail.com', '45789', 'googlepay', '2021-08-08', 87);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `pid` int(11) NOT NULL,
  `pname` varchar(200) NOT NULL,
  `ctype` varchar(200) NOT NULL,
  `ptype` varchar(200) NOT NULL,
  `qty` int(11) NOT NULL,
  `unit` varchar(200) NOT NULL,
  `rate` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pid`, `pname`, `ctype`, `ptype`, `qty`, `unit`, `rate`) VALUES
(4, 'rice', 'Grocery', 'ambemohor', 1000, 'kg', 55),
(5, 'wheat', 'Grocery', 'lahu', 500, 'kg', 32),
(6, 'ponds', 'Cosmetics', 'purple', 50, 'number', 55);

-- --------------------------------------------------------

--
-- Table structure for table `quotation`
--

CREATE TABLE `quotation` (
  `qid` int(11) NOT NULL,
  `pname` varchar(200) NOT NULL,
  `ctype` varchar(200) NOT NULL,
  `ptype` varchar(200) NOT NULL,
  `qty` int(11) NOT NULL,
  `unit` varchar(200) NOT NULL,
  `rate` int(11) NOT NULL,
  `uname` varchar(200) NOT NULL,
  `status` int(11) NOT NULL,
  `dateofq` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quotation`
--

INSERT INTO `quotation` (`qid`, `pname`, `ctype`, `ptype`, `qty`, `unit`, `rate`, `uname`, `status`, `dateofq`) VALUES
(11, 'rice', 'Grocery', 'ambemohor', 500, 'kg', 28, 'ganesh0633@gmail.com', 2, '2021-08-08');

-- --------------------------------------------------------

--
-- Table structure for table `spayment`
--

CREATE TABLE `spayment` (
  `pid` int(11) NOT NULL,
  `qid` int(11) NOT NULL,
  `pname` varchar(200) NOT NULL,
  `ctype` varchar(200) NOT NULL,
  `qty` int(11) NOT NULL,
  `unit` varchar(200) NOT NULL,
  `rate` int(11) NOT NULL,
  `sname` varchar(200) NOT NULL,
  `status` int(11) NOT NULL,
  `date` varchar(200) NOT NULL,
  `tid` varchar(200) NOT NULL,
  `mop` varchar(200) NOT NULL,
  `ptype` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `spayment`
--

INSERT INTO `spayment` (`pid`, `qid`, `pname`, `ctype`, `qty`, `unit`, `rate`, `sname`, `status`, `date`, `tid`, `mop`, `ptype`) VALUES
(4, 11, 'rice', 'Grocery', 500, 'kg', 28, 'ganesh0633@gmail.com', 2, '2021-08-08', '123456', 'google pay', 'ambemohor');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `fname` varchar(200) NOT NULL,
  `mname` varchar(200) NOT NULL,
  `lname` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `mobileno` varchar(200) NOT NULL,
  `adhaar` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`fname`, `mname`, `lname`, `username`, `password`, `address`, `mobileno`, `adhaar`, `email`) VALUES
('ganesh', 'chandrakant', 'rampure', 'ganesh0633@gmail.com', 'abcdefgh', 'solapur', '8999050631', '1245637896', 'ganesh0633@gmail.com'),
('MAHADEVI', 'DHARMARAO', 'PATIL', 'rajhundekari@gmail.com', 'abcdefgh', 'patil wasti  vijapur road\r\nSaiful', '9028285086', '78967889', 'mahesh@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`invoiceid`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `quotation`
--
ALTER TABLE `quotation`
  ADD PRIMARY KEY (`qid`);

--
-- Indexes for table `spayment`
--
ALTER TABLE `spayment`
  ADD PRIMARY KEY (`pid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `invoiceid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `quotation`
--
ALTER TABLE `quotation`
  MODIFY `qid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `spayment`
--
ALTER TABLE `spayment`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
