<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body background-color="green"><p align="center">
	<h1 class="text-warning">Admin Dashboard</h1>
	 <div class="list-group">
    <a href="addproduct.php" class="list-group-item list-group-item-success">Add Product</a>
    <a href="viewstock.php" class="list-group-item list-group-item-info">View Stock</a>
    <a href="viewquotation.php" class="list-group-item list-group-item-warning">View Quotation</a>
    <a href="viewpayment.php" class="list-group-item list-group-item-success">View Supplier Payment</a>
    <a href="deliveryreport.php" class="list-group-item list-group-item-info">View Delivery Status</a>
    <a href="datewisestockreport.php" class="list-group-item list-group-item-warning">Product Wise Stock Report</a>
    <a href="datewisequotationreport.php" class="list-group-item list-group-item-success">Date Wise Quotation Report</a>
     <a href="supplierwisereport.php" class="list-group-item list-group-item-info">Suppier Wise Quotation Report</a>
      <a href="productwisequotationreport.php" class="list-group-item list-group-item-warning">Product Wise Quotation Report</a>
      <a href="datewisesupplierpaymentreport.php" class="list-group-item list-group-item-success">Date Wise Supplier Payment Report</a>
      <a href="suppliernamewisepaymentreport.php" class="list-group-item list-group-item-info">Supplier Wise Payment Report</a>
      <a href="mopreport.php" class="list-group-item list-group-item-warning">Mode Wise Supplier Payment Report</a>
       <a href="datewisecustomerreport.php" class="list-group-item list-group-item-success">Date Wise Customer Payment Report</a>
       <a href="customernamewisereport.php" class="list-group-item list-group-item-info">Customer Wise Payment Report</a>
       <a href="mopcreport.php" class="list-group-item list-group-item-warning">Mode Wise Customer Payment Report</a>
       <a href="deliverycreport.php" class="list-group-item list-group-item-success">Delivery Wise Customer  Report</a>
    
  </div>
</p>
</body>
</html>